from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from django.http import HttpResponse
from django.db import IntegrityError
from .forms import CrearGastoForm
from .models import CrearGasto
from django.urls import reverse
from django.utils import timezone
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
    return render(request, 'home.html')

def signup(request):
    if request.method == 'GET':
            return render(request, 'signup.html',{
            'form': UserCreationForm
        })
    else:
        if request.POST['password1'] == request.POST['password2']:
            try:
                user = User.objects.create_user(username=request.POST['username'],
                password = request.POST['password1'])
                user.save()
                login(request, user)
                return redirect('crearGasto')
            except IntegrityError:
                return render(request, 'signup.html',{
                    'form': UserCreationForm,
                    "error": 'Usuario ya existe'
        })
        return render(request, 'signup.html',{
            'form': UserCreationForm,
            "error": 'Las contraseñas no coinciden'
        })

@login_required 
def verGastos(request):
    gastos = CrearGasto.objects.filter(user=request.user, datecompleted__isnull=True ) 
    
    return render(request, 'verGastos.html',{'Gastos' : gastos})

@login_required 
def verGastosCompletados(request):
    gastos = CrearGasto.objects.filter(user=request.user, datecompleted__isnull=False).order_by
    ('-datecompleted') 
    
    return render(request, 'verGastos.html',{'Gastos' : gastos})

@login_required 
def signout(request):
    logout(request)
    return redirect('home')

def signin(request):
     if request.method=='GET':
          return render(request, 'signin.html', {
               'form': AuthenticationForm
          })
     else:
          user = authenticate(request, username=request.POST['username'], password=request.POST
                       ['password'])
          if user is None:
            return render(request, 'signin.html',{
               'form': AuthenticationForm,
               'error': 'El usuario o la contraseña son incorrectos'
          })   
          else:
              login(request, user)
              return redirect('verGastos')
          
@login_required 
def crearGastos(request):
    if request.method == 'GET':
        return render(request, 'crearGastos.html', {'form': CrearGastoForm})
    else:
        try:
            form = CrearGastoForm(request.POST)
            new_task = form.save(commit=False)
            new_task.user = request.user 
            new_task.save()
            return redirect(reverse('verGastos'))  # Utiliza reverse() para obtener la URL
        except ValueError:
            return render(request, 'crearGastos.html', {
                'form': CrearGastoForm,
                'error': 'Ingresa datos válidos'
            })
        
@login_required         
def gastoDetail(request, gasto_id):

    if request.method == 'GET':
        crearGasto = get_object_or_404(CrearGasto, pk=gasto_id, user = request.user)
        form = CrearGastoForm(instance = crearGasto)
        return render(request, 'gastoDetail.html' , {'gasto' : crearGasto, 'form' : form})
    else:
        try:
            crearGasto = get_object_or_404 (CrearGasto, pk = gasto_id)
            form = CrearGastoForm(request.POST, instance = crearGasto)
            form.save()
            return redirect('verGastos')
        except ValueError:
            return render(request, 'gastoDetail.html' , {'gasto' : crearGasto, 'form' : form, 
            'error' : "Error actualizando el gasto"})

@login_required 
def completeGasto(request, gasto_id):
    crearGastos = get_object_or_404(CrearGasto, pk = gasto_id, user = request.user)
    if request.method == 'POST':
        crearGastos.datecompleted = timezone.now()
        crearGastos.save()
        return redirect('verGastos')
    
@login_required 
def deleteGasto(request, gasto_id):
    crearGastos = get_object_or_404(CrearGasto, pk = gasto_id, user = request.user)
    if request.method == 'POST':
        crearGastos.delete()
        return redirect('verGastos')