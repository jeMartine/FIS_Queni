from django.contrib import admin
from .models import CrearGasto

class CrearGastoAdmin(admin.ModelAdmin):
    readonly_fields = ("datecreated" ,)

# Register your models here.
admin.site.register(CrearGasto, CrearGastoAdmin)

