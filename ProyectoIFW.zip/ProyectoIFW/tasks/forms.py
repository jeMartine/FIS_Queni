from django.forms import ModelForm
from .models import CrearGasto

class CrearGastoForm(ModelForm):
    class Meta:
        model = CrearGasto
        fields = ['Nombre', 'TipoGasto', 'Descripcion', 'Valor', 'important']