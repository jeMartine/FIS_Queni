from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class CrearGasto(models.Model):
    Nombre = models.CharField(max_length=50)
    TipoGasto = models.CharField(max_length=50)
    Descripcion = models.TextField(blank=True)
    Valor = models.BigIntegerField(default=0, blank=True, null=True) 
    datecreated = models.DateTimeField(auto_now_add=True)
    datecompleted = models.DateTimeField(null=True)
    important = models.BooleanField(default=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    

    def __str__(self):
        return self.Nombre + ' creado por: ' + self.user.username
